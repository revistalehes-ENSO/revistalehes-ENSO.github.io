%% =====================================================================
%%  lehes.cls · Clase LaTeX de la Revista LEHES
%%  Revista: Leer, Escribir, Hablar & Escuchar
%%  Escuela Normal Superior Oiba · Oiba, Santander, Colombia
%%  ---------------------------------------------------------------------
%%  Compilar con XeLaTeX (o LuaLaTeX). En Overleaf: Menú > Compiler > XeLaTeX.
%%  Los colores y tipografías se cambian en la sección "PANEL DE CONTROL".
%% =====================================================================
\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{lehes}[2026/10/31 Revista LEHES v1.0]
\LoadClass[12pt,letterpaper]{article}

%% ---------- Paquetes ----------
\RequirePackage{babel}
\babelprovide[import,main,hyphenrules=spanish]{spanish}
\babelprovide[import]{english}
\AtBeginDocument{\renewcommand{\tablename}{Tabla}\renewcommand{\figurename}{Figura}\renewcommand{\listtablename}{Índice de tablas}}
\RequirePackage{fontspec}
\RequirePackage[letterpaper,top=2.5cm,bottom=3.2cm,left=2.5cm,right=2.5cm,footskip=1.6cm]{geometry}
\RequirePackage{xcolor}
\RequirePackage{graphicx}
\RequirePackage{tikz}
\usetikzlibrary{shadings}
\RequirePackage{fancyhdr}
\RequirePackage{titlesec}
\RequirePackage{setspace}
\RequirePackage{multicol}
\RequirePackage{enumitem}
\RequirePackage[font=normalsize,labelfont=bf,textfont=it,labelsep=newline,singlelinecheck=false,justification=raggedright]{caption}
\RequirePackage{booktabs}
\RequirePackage{array}
\RequirePackage{csquotes}
\RequirePackage[hidelinks]{hyperref}
\RequirePackage{xurl}
\RequirePackage[protrusion=true]{microtype}
%% Contra palabras desbordadas: margen de tolerancia y estiramiento de emergencia
\tolerance=2000 \emergencystretch=3em \hbadness=10000
\hyphenpenalty=50 \lefthyphenmin=2 \righthyphenmin=2

%% =====================================================================
%%  PANEL DE CONTROL · colores y tipografías (los mismos nombres del sitio web)
%% =====================================================================
\definecolor{azulnoche}{HTML}{1A1B41}    % fondo del logo LEHES
\definecolor{ambar}{HTML}{FBAF00}        % la H del logo LEHES
\definecolor{rojoenso}{HTML}{B3191F}     % escudo ENSO
\definecolor{verdeenso}{HTML}{2F8F46}    % escudo ENSO
\definecolor{azularticulo}{HTML}{2B6497} % franja del pie de página
\definecolor{celeste}{HTML}{5B9BD5}      % línea bajo los títulos
\definecolor{grisclaro}{HTML}{A6B7CB}    % final de la franja del pie
\definecolor{grislinea}{HTML}{808080}    % líneas de la cabecera
\definecolor{grisingles}{HTML}{7F7F7F}   % título en inglés

\setmainfont{EBGaramond}[
  Path=fuentes/, Extension=.otf,
  UprightFont=*-Regular, ItalicFont=*-Italic,
  BoldFont=*-Bold, BoldItalicFont=*-BoldItalic, Ligatures=TeX]
\newfontfamily\letrapie{Carlito-Regular.ttf}[Path=fuentes/]
\newfontfamily\letratitulos{texgyreadventor}[
  Path=fuentes/, Extension=.otf,
  UprightFont=*-regular, ItalicFont=*-italic,
  BoldFont=*-bold, BoldItalicFont=*-bolditalic]

%% ---------- Interlineado y párrafos (APA 7) ----------
\onehalfspacing
\setlength{\parindent}{1.27cm}
\setlength{\parskip}{0pt}
\raggedbottom

%% ---------- Metadatos del artículo ----------
\newcommand{\lehes@titulo}{[Título del artículo en español]}
\newcommand{\lehes@tituloingles}{[Article title in English]}
\newcommand{\lehes@titulocorto}{[Título corto]}
\newcommand{\lehes@tipo}{Artículo de investigación original}
\newcommand{\lehes@recibido}{[mes día, año]}
\newcommand{\lehes@aceptado}{[mes día, año]}
\newcommand{\lehes@aprobado}{[mes día, año]}
\newcommand{\lehes@volumen}{[vol]}
\newcommand{\lehes@numero}{[núm]}
\newcommand{\lehes@anio}{[año]}
\newcommand{\lehes@mes}{[mes]}
\newcommand{\lehes@paginas}{[pp]}
\newcommand{\lehes@autorapa}{[Apellidos, I. I.]}
\newcommand{\lehes@autorcorto}{[Autor(es)]}
\newcommand{\lehes@correspondencia}{[Nombre completo, ciudad, país. Email: correo@ejemplo.com]}
\newcommand{\lehes@autores}{}
\newcommand{\limpiarautores}{\gdef\lehes@autores{}}
\def\lehes@doi{}

\newcommand{\titulo}[1]{\renewcommand{\lehes@titulo}{#1}}
\newcommand{\tituloingles}[1]{\renewcommand{\lehes@tituloingles}{#1}}
\newcommand{\titulocorto}[1]{\renewcommand{\lehes@titulocorto}{#1}}
\newcommand{\tipoarticulo}[1]{\renewcommand{\lehes@tipo}{#1}}
\newcommand{\recibido}[1]{\renewcommand{\lehes@recibido}{#1}}
\newcommand{\aceptado}[1]{\renewcommand{\lehes@aceptado}{#1}}
\newcommand{\aprobado}[1]{\renewcommand{\lehes@aprobado}{#1}}
\newcommand{\volumen}[1]{\renewcommand{\lehes@volumen}{#1}}
\newcommand{\numero}[1]{\renewcommand{\lehes@numero}{#1}}
\newcommand{\anio}[1]{\renewcommand{\lehes@anio}{#1}}
\newcommand{\mes}[1]{\renewcommand{\lehes@mes}{#1}}
\newcommand{\paginas}[1]{\renewcommand{\lehes@paginas}{#1}}
\newcommand{\autorapa}[1]{\renewcommand{\lehes@autorapa}{#1}}
\newcommand{\autorcorto}[1]{\renewcommand{\lehes@autorcorto}{#1}}
\newcommand{\correspondencia}[1]{\renewcommand{\lehes@correspondencia}{#1}}
\newcommand{\doi}[1]{\def\lehes@doi{#1}}
%% \autor{Nombre completo}{correo}{ORCID sin https}{Filiación}
\newcommand{\autor}[4]{%
  \g@addto@macro\lehes@autores{%
    {\large #1}\\
    {\small #4}\\
    Email: \href{mailto:#2}{\textcolor{azularticulo}{#2}}\\
    \href{https://orcid.org/#3}{\textcolor{azularticulo}{https://orcid.org/#3}}\\[8pt]}}

%% ---------- Títulos de sección (niveles APA 7) ----------
\titleformat{\section}{\centering\bfseries\large}{}{0pt}{}
\titleformat{\subsection}{\bfseries}{}{0pt}{}
\titleformat{\subsubsection}{\bfseries\itshape}{}{0pt}{}
\titleformat{\paragraph}[runin]{\bfseries}{}{0pt}{}[.]
\titlespacing*{\section}{0pt}{18pt}{8pt}
\titlespacing*{\subsection}{0pt}{14pt}{6pt}
\titlespacing*{\subsubsection}{0pt}{12pt}{4pt}
\setcounter{secnumdepth}{0}

%% ---------- Pie de página: dos flechas con degradado, igual al original ----------
%% Medidas tomadas del artículo original: 162 mm de ancho, 5,3 mm de alto,
%% degradado azul oscuro -> celeste (60 %) -> gris azulado; texto negro en Calibri.
\definecolor{flechaceleste}{HTML}{66A2D8} % punto más claro del degradado
\pgfdeclarehorizontalshading{lehesflecha}{100bp}{%
  color(0bp)=(azularticulo); color(25bp)=(azularticulo); color(54bp)=(flechaceleste); color(75bp)=(grisclaro); color(100bp)=(grisclaro)}
\newlength{\lehes@anchotexto}
\newcommand{\lehes@ajustar}[2]{% escala el texto solo si no cabe en #1
  \settowidth{\lehes@anchotexto}{#2}%
  \ifdim\lehes@anchotexto>#1\resizebox{#1}{!}{#2}\else#2\fi}
\newcommand{\lehes@franja}{%
  \begin{tikzpicture}[x=1mm,y=1mm]
    \def\h{5.3}\def\d{2.7}\def\L{91}\def\R{92.6}\def\F{162}
    \shade[shading=lehesflecha]
      (0,0) -- (\L,0) -- (\L+\d,\h/2) -- (\L,\h) -- (0,\h) -- (\d,\h/2) -- cycle;
    \shade[shading=lehesflecha]
      (\R,0) -- (\F-\d,0) -- (\F,\h/2) -- (\F-\d,\h) -- (\R,\h) -- (\R+\d,\h/2) -- cycle;
    \node[anchor=west, inner sep=0pt, text=black, font=\letrapie\fontsize{5}{6}\selectfont]
      at (\d+2.6,\h/2) {\lehes@ajustar{82mm}{\lehes@titulocorto}};
    \node[anchor=east, inner sep=0pt, text=black, font=\letrapie\fontsize{5}{6}\selectfont]
      at (\F-\d-2.6,\h/2) {\lehes@ajustar{62mm}{\lehes@autorcorto}};
  \end{tikzpicture}}
\pagestyle{fancy}
\fancyhf{}
\renewcommand{\headrulewidth}{0pt}
\fancyfoot[C]{\lehes@franja\\[1pt]{\normalsize\thepage}}
%% Restablece el pie de los artículos (por si otro estilo de página lo borró)
\newcommand{\estiloarticulos}{\pagestyle{fancy}\fancyhf{}\renewcommand{\headrulewidth}{0pt}%
  \fancyfoot[C]{\lehes@franja\\[1pt]{\normalsize\thepage}}}
\fancypagestyle{portada}{\fancyhf{}\renewcommand{\headrulewidth}{0pt}}

%% ---------- Portada (página 1) ----------
\newcommand{\portadaLEHES}{%
  \thispagestyle{portada}%
  \noindent{\color{grislinea}\rule{\textwidth}{1.2pt}}\par\vspace{10pt}
  \noindent
  \begin{minipage}[t]{0.5\textwidth}\vspace{0pt}
    \includegraphics[width=3.8cm]{img/logo-lehes.png}\\[-2pt]
    {\letratitulos\footnotesize\setstretch{1}Revista: Leer, Escribir,\\\hspace*{1.2em}Hablar \& Escuchar\par}
  \end{minipage}\hfill
  \begin{minipage}[t]{0.3\textwidth}\vspace{0pt}\raggedleft
    \includegraphics[width=2.9cm]{img/escudo-enso.png}
  \end{minipage}\par\vspace{4pt}
  \noindent{\color{grislinea}\rule{\textwidth}{1.6pt}}\par
  \vspace{0.8cm}
  \begin{center}\setstretch{1.05}
    {\letratitulos\bfseries\fontsize{21}{25}\selectfont \lehes@titulo\par}\vspace{10pt}
    {\letratitulos\bfseries\fontsize{18}{22}\selectfont\color{grisingles} \lehes@tituloingles\par}
  \end{center}
  \vspace{6pt}
  \noindent{\color{celeste}\rule{\textwidth}{2.2pt}}\par\vspace{8pt}
  \noindent
  \begin{minipage}[t]{0.5\textwidth}\vspace{0pt}\raggedright\setstretch{1.05}
    {\letratitulos\bfseries\large \lehes@tipo\par}\vspace{12pt}
    \textbf{Recibido:} \lehes@recibido\\
    \textbf{Aceptado:} \lehes@aceptado\\
    \textbf{Aprobado:} \lehes@aprobado\par\vspace{12pt}
    {\large\textbf{Cómo citar este artículo:}}\par
    {\small\setstretch{1}\lehes@autorapa\ (\lehes@anio). \lehes@titulo. \textit{LEHES. Revista Leer, Escribir, Hablar \& Escuchar}, \textit{\lehes@volumen}(\lehes@numero), \lehes@paginas.\ifx\lehes@doi\@empty\else\ \url{https://doi.org/\lehes@doi}\fi\par}\vspace{10pt}
    {\large\textbf{Correspondencia:}}\par{\small\setstretch{1}\lehes@correspondencia\par}\vspace{8pt}
    \includegraphics[width=3cm]{img/cc-by-nc-nd.png}\\
    {\scriptsize\setstretch{1}Licencia Creative Commons Atribución-NoComercial-SinDerivadas 4.0 Internacional.\par}
  \end{minipage}\hfill
  \begin{minipage}[t]{0.45\textwidth}\vspace{18pt}\raggedleft\setstretch{1.05}
    \lehes@autores
  \end{minipage}
  \clearpage}

%% ---------- Resumen y Abstract (página 2, a dos columnas) ----------
\newcommand{\lehes@resumen}{}\newcommand{\lehes@abstract}{}
\newcommand{\lehes@palabras}{}\newcommand{\lehes@keywords}{}
\newcommand{\resumen}[1]{\renewcommand{\lehes@resumen}{#1}}
\renewcommand{\abstract}[1]{\renewcommand{\lehes@abstract}{#1}}
\newcommand{\palabrasclave}[1]{\renewcommand{\lehes@palabras}{#1}}
\newcommand{\keywords}[1]{\renewcommand{\lehes@keywords}{#1}}
\newcommand{\resumenesLEHES}{%
  \begin{center}\setstretch{1.1}
    {\bfseries\large \lehes@titulo\par}\vspace{4pt}
    {\color{celeste}\rule{0.92\textwidth}{1.4pt}}
  \end{center}\vspace{10pt}
  \noindent
  \begin{minipage}[t]{0.47\textwidth}\setstretch{1.15}\setlength{\parindent}{0pt}
    \centerline{\bfseries\large Abstract}\vspace{8pt}
    \begin{otherlanguage}{english}\lehes@abstract\par\end{otherlanguage}
    \vspace{10pt}{\large\textbf{Keywords:}} \lehes@keywords\par
  \end{minipage}\hfill
  \begin{minipage}[t]{0.47\textwidth}\setstretch{1.15}\setlength{\parindent}{0pt}
    \centerline{\bfseries\large Resumen}\vspace{8pt}
    \lehes@resumen\par
    \vspace{10pt}{\large\textbf{Palabras clave:}} \lehes@palabras\par
  \end{minipage}
  \clearpage}
\providecommand{\justifying}{}

%% ---------- Declaraciones finales obligatorias ----------
\newcommand{\declaracionesLEHES}[4]{%
  \section{Implicaciones éticas}#1
  \section{Contribución de los autores}#2
  \section{Declaración de fuentes de financiación}#3
  \section{Conflictos de interés}#4}

%% ---------- Referencias en APA 7 (sangría francesa) ----------
\newenvironment{referencias}{%
  \section{Referencias}
  \begin{list}{}{\setlength{\leftmargin}{1.27cm}\setlength{\itemindent}{-1.27cm}%
    \setlength{\itemsep}{4pt}\setlength{\parsep}{0pt}}\raggedright}%
  {\end{list}}
\newcommand{\referencia}{\item\relax}

%% ---------- Notas de figuras y tablas (APA 7) ----------
\newcommand{\notafuente}[1]{\par\vspace{2pt}{\small\textit{Nota.} #1\par}}
\endinput
